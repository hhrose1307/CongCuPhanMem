﻿$(function () {
    $('#AlertBox').removeClass('hide');
    $('#AlertBox').delay(1000).slideUp(500);
});